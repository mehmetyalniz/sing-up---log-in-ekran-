package com.example.bitirmeprojesi;

import android.view.View;

public class ViewOnClickListener implements View.OnClickListener {
    @Override
    public void onClick(View v) {

    }
}
